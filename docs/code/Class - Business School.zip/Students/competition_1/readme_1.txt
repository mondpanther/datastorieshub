For this exercise you will need to estimate a logistic regression on a crime dataset. 
You can find info on the dataset at https://archive.ics.uci.edu/ml/datasets/Communities+and+Crime+Unnormalized
The variable of interest is larcenies per capita (larcPerPop). 
The variable has been binarized, and it is equal to one when larcenies per capita are high (above median level), and equal to zero when larcenies per capita are low (below median level).
You will need to use the following files:
- �template_1_XX.R� (pick the one of your group, e.g. �template_1_A.R� for group A)
- �train_1.R�
- �crime_competition.csv�
Put all three files in the same folder, open RStudio and set the working directory in the folder where you put the above files.
Use the file �template_1_XX.R� to specify the formula of your model, i.e. the covariates you want to use, and save the changes.
Finally, use the file �train_1.R� to assess the forecasting performance of your model. 
This file contains a function called �train_1�. 
Run the function to add it to your environment. 
Once you have done this, you can call function train_1() to assess your model. 
This function only needs as argument the name of your model. 
Therefore, use
- train_1(groups = �A�) if you are group A
- train_1(groups = �B�) for group B
- and so on
To try different models, just change the formula in the file �template_1_XX.R� and save the changes. 
Then, run the function train_1() specifying the letter of your group, as shown above.
Once you are happy with your model, email your �template_1_XX.R� file to deMontjoye@imperial.ac.uk coping d.benedetti@imperial.ac.uk

