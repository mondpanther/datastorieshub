
# select the covariates of your model
# do not change the dependent variables
# only write the variables you want to use, 
# e.g. "larcPerPop ~ population + householdsize"
# load the crime dataset and check the variables to decide which ones to use

formula <- "larcPerPop ~ householdsize"

