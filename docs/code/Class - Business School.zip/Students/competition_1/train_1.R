
train_1 <- function(
  group = LETTERS[1:12],
  seed = 100,          # seed for random generation (default = 100)
  warns = -1
) {
  
  require(caret)
  options(warn=warns)
  # set the seed
  set.seed(seed)
  
  crime <- read.csv("crime_competition.csv")
  crime$larcPerPop <- factor(crime$larcPerPop,levels = c(0,1), labels = c("0","1"))
  
  source(paste0("template_1_",group[1],".R"))
  
  logit.mod <- glm(formula(formula), data = crime, 
                   family = binomial(logit)) 
  
  fitted.results <- predict(logit.mod, newdata=crime, type="response") # predict probabilities
  fitted.results <- ifelse(fitted.results > 0.5,1,0) # convert to binary
  fitted.results <- factor(fitted.results,levels = c(0,1), labels = c("0","1"))
  performance <- confusionMatrix(fitted.results,
                                 crime[,"larcPerPop"])
  
  cat(paste(
    '\n',
    sprintf('\nAccuracy: %0.4f', performance$overall[1]),  # 1 for Accuracy
    #sprintf('\nPrecision: %0.4f', performance$byClass[4]), # 4 for Neg Pred Value (survived) # use this
    #sprintf('\nRecall: %0.4f', performance$byClass[2]),    # 2 for Specificity (survived) # use this one
    '\n'
  ))
  
}
