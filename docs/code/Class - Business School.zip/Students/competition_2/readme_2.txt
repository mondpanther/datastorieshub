For this exercise you will need to estimate a classification model on an income dataset. 
You can find info on the dataset at https://archive.ics.uci.edu/ml/datasets/adult
You are free to decide whether to use a logistic, tree, or svm model.
The variable of interest is income (X..50K). The variable is equal to �>50K�  when income is above median values, and �<=50K�  when it is below.
You will need to use the following files:
- �template_2_XX.R� (pick the one of your group, e.g. �template_1_A.R� for group A)
- �train_2.R�
- �adult_competition.csv�
Put all three files in the same folder, open RStudio and set the working directory in the folder where you put the above files.
Use the file �template_2_XX.R� to specify the formula of your model, i.e. the covariates you want to use, and save the changes.
Then specify the model you want to use, either �logit� (for logistic), �tree� (for tree), or � svm� (for svm). 
In case you decide for tree model also specify maxdepth and cp. 
In case you decide for svm model also specify cost and gamma.
Finally, use the file �train_2.R� to assess the forecasting performance of your model.
This file contains a function called �train_2�. 
Run the function to add it to your environment. 
Once you have done this, you can call function train_2() to assess your model. 
This function only needs as argument the name of your group. 
Therefore, use
- train_2(groups = �A�) if you are group A
- train_2(groups = �B�) for group B
- and so on
Try different models. 
To do so, just change the formula, model type (and associated parameters) in the file �template_2_XX.R� and save the changes. 
Then, run the function train_2() specifying the letter of your group, as shown above.
Once you are happy with your model, email your �template_2_XX.R� file to deMontjoye@imperial.ac.uk coping d.benedetti@imperial.ac.uk

