
# select the model that you wish to use
# insert either "logit", "tree" or "svm" instead of NULL
model <- NULL

# select the covariates of your model
# do not change the dependent variables
# only write the variables you want to use, 
# e.g. "X..50K ~ State.gov + Never.married"
# load the adult dataset and check the variables to decide which ones to use
formula <- "X..50K ~ Never.married"

# if you select tree model also specify maxdepth and cp
maxdepth <- 4
cp <- 0.01

# if you select svm model also specify cost and gamma
cost <- 1
gamma <- 1


