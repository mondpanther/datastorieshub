
train_2 <- function(
  group = LETTERS[1:12],
  seed = 100,          # seed for random generation (default = 100)
  first_split = 0.4,
  second_split = 0.5,
  warns = -1
) {
  
  require(caret)
  require(rpart)
  require(e1071)
  options(warn=warns)
  # set the seed
  set.seed(seed)
  
  adult <- read.csv("adult_competition.csv")
  
  train_size <- floor(first_split * nrow(adult))
  train_id <- sample(seq_len(nrow(adult)), train_size, replace = FALSE)
  train_h <- adult[train_id,]
  test_and_val_h <- adult[-train_id,]
  
  val_size <- floor(second_split * nrow(test_and_val_h))
  val_id <- sample(seq_len(nrow(test_and_val_h)), val_size, replace = FALSE)
  test_h <- test_and_val_h[-val_id,]
  val_h <- test_and_val_h[val_id,]
  
  train_h$X..50K <- ordered(train_h$X..50K, c(" <=50K"," >50K"))
  val_h$X..50K <- ordered(val_h$X..50K, c(" <=50K"," >50K"))
  test_h$X..50K <- ordered(test_h$X..50K, c(" <=50K"," >50K"))
  
  source(paste0("template_2_",group[1],".R"))
  
  performance <- data.frame(group = group[1],
                            model = model,
                            a1 = NA,
                            p1 = NA,
                            r1 = NA,
                            a2 = NA,
                            p2 = NA,
                            r2 = NA,
                            p = NA)
  
  if(model == "logit"){
    logit.mod <- glm(formula(formula), data = train_h, 
                     family = binomial(logit)) 
    
    fitted.results <- predict(logit.mod, newdata=train_h, type="response") # predict probabilities
    fitted.results <- ifelse(fitted.results > 0.5,1,0) # convert to binary
    fitted.results <- factor(fitted.results,levels = c(0,1), labels = c(" <=50K"," >50K"))
    performance1 <- confusionMatrix(fitted.results,
                                    train_h[,"X..50K"])
    
    fitted.results <- predict(logit.mod, newdata=val_h, type="response") # predict probabilities
    fitted.results <- ifelse(fitted.results > 0.5,1,0) # convert to binary
    fitted.results <- factor(fitted.results,levels = c(0,1), labels = c(" <=50K"," >50K")) # convert to binary
    performance2 <- confusionMatrix(fitted.results,
                                    val_h[,"X..50K"])
    
    
    performance$a1[1] <- round(performance1$overall[1],3)
    performance$p1[1] <- round(performance1$byClass[4],3)
    performance$r1[1] <- round(performance1$byClass[2],3)
    performance$a2[1] <- round(performance2$overall[1],3)
    performance$p2[1] <- round(performance2$byClass[4],3)
    performance$r2[1] <- round(performance2$byClass[2],3)
    performance$p[1] <- paste0("params = ", length(logit.mod$coefficients) - 1)
  }
  
  if(model == "tree"){
    tree.mod <- rpart(formula(formula), data = train_h, maxdepth = maxdepth, cp = cp) 
    
    fitted.results <- predict(tree.mod, newdata=train_h, type="class") # predict probabilities
    performance1 <- confusionMatrix(fitted.results,
                                    train_h[,"X..50K"])
    
    fitted.results <- predict(tree.mod, newdata=val_h, type="class") # predict probabilities
    performance2 <- confusionMatrix(fitted.results,
                                    val_h[,"X..50K"])
    
    
    performance$a1[1] <- round(performance1$overall[1],3)
    performance$p1[1] <- round(performance1$byClass[4],3)
    performance$r1[1] <- round(performance1$byClass[2],3)
    performance$a2[1] <- round(performance2$overall[1],3)
    performance$p2[1] <- round(performance2$byClass[4],3)
    performance$r2[1] <- round(performance2$byClass[2],3)
    performance$p[1] <- paste0("maxdepth = ", maxdepth," cp = ", cp)
  }
  
  if(model == "svm"){
    svm.mod <- svm(formula(formula), data = train_h, cost = cost, gamma = gamma) 
    
    fitted.results <- predict(svm.mod, newdata=train_h) # predict probabilities
    performance1 <- confusionMatrix(fitted.results,
                                    train_h[,"X..50K"])
    
    fitted.results <- predict(svm.mod, newdata=val_h) # predict probabilities
    performance2 <- confusionMatrix(fitted.results,
                                    val_h[,"X..50K"])
    
    
    performance$a1[1] <- round(performance1$overall[1],3)
    performance$p1[1] <- round(performance1$byClass[4],3)
    performance$r1[1] <- round(performance1$byClass[2],3)
    performance$a2[1] <- round(performance2$overall[1],3)
    performance$p2[1] <- round(performance2$byClass[4],3)
    performance$r2[1] <- round(performance2$byClass[2],3)
    performance$p[1] <- paste0("cost = ", cost," gamma = ", gamma)
  }
  
  colnames(performance) <- c("group",
                             "model",
                             "accuracy in train",
                             "precision in train",
                             "recall in train",
                             "accuracy in validation",
                             "precision in validation",
                             "recall in validation",
                             "parameters"
  )
  
  return(performance)
  
  
}
